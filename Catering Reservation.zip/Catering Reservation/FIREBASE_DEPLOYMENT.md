# Firebase Deployment Guide for Shakthi Catering Reservation System

## Prerequisites
- Firebase CLI installed ✅
- Firebase project created (if not, create one at https://console.firebase.google.com/)
- Google account with Firebase access

## Deployment Steps

### 1. Login to Firebase
```bash
firebase login
```

### 2. Initialize Firebase Project (if not already done)
```bash
firebase init
```
Select:
- Hosting: Configure files for Firebase Hosting
- Functions: Configure a Cloud Functions directory

### 3. Configure Firebase Functions Environment
Set up email configuration for Functions:
```bash
firebase functions:config:set email.user="your_email@gmail.com" email.pass="your_app_password" email.business="shakthiisivakumar@gmail.com"
```

### 4. Deploy Functions
```bash
firebase deploy --only functions
```

### 5. Deploy Hosting
```bash
firebase deploy --only hosting
```

### 6. Deploy Everything
```bash
firebase deploy
```

## Environment Configuration

### Email Setup (Gmail)
1. Enable 2-factor authentication on Gmail
2. Generate App Password:
   - Go to Google Account settings
   - Security > App passwords
   - Generate password for "Mail"
3. Use the generated password in the config command above

### Database
- Firebase Functions automatically use Firestore
- No additional database setup required
- Data will be stored in collections: `reservations` and `contact_messages`

## Testing Deployment

### Local Testing
```bash
# Start local emulators
firebase emulators:start

# Your app will be available at:
# - Hosting: http://localhost:5000
# - Functions: http://localhost:5001
```

### Production Testing
After deployment, your app will be available at:
`https://your-project-id.web.app`

## Commands Summary

```bash
# Install dependencies
cd functions && npm install

# Login to Firebase
firebase login

# Deploy functions only
firebase deploy --only functions

# Deploy hosting only
firebase deploy --only hosting

# Deploy everything
firebase deploy

# View logs
firebase functions:log

# Local development
firebase emulators:start
```

## Firestore Security Rules

Add these rules to your Firestore (Firebase Console > Firestore > Rules):

```javascript
rules_version = '2';
service cloud.firestore {
  match /databases/{database}/documents {
    // Allow read/write access to reservations
    match /reservations/{reservationId} {
      allow read, write: if true;
    }
    
    // Allow read/write access to contact messages
    match /contact_messages/{messageId} {
      allow read, write: if true;
    }
  }
}
```

## Troubleshooting

### Common Issues:
1. **Functions not deploying**: Check Node.js version (should be 18 or 20)
2. **Email not working**: Verify email configuration with `firebase functions:config:get`
3. **CORS issues**: Functions handle CORS automatically
4. **Firestore permissions**: Update security rules as shown above

### Debug Commands:
```bash
# Check function logs
firebase functions:log

# Check configuration
firebase functions:config:get

# Test functions locally
firebase emulators:start --only functions
```

## Cost Optimization

### Firebase Pricing:
- **Firestore**: Free tier includes 50,000 reads/day
- **Functions**: Free tier includes 2M invocations/month
- **Hosting**: Free tier includes 10GB storage

### Optimization Tips:
- Use Firestore efficiently (minimal reads/writes)
- Implement pagination for large data sets
- Cache frequently accessed data

## Support

For issues:
1. Check Firebase Console logs
2. Use `firebase functions:log` for function debugging
3. Test locally with emulators first
4. Contact: shakthiisivakumar@gmail.com

---

🚀 Your Shakthi Catering Reservation System is ready for Firebase deployment!
