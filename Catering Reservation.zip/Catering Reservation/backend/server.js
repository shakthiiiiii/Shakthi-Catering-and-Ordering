const express = require('express');
const cors = require('cors');
const mysql = require('mysql2');
const bodyParser = require('body-parser');
const nodemailer = require('nodemailer');
require('dotenv').config();

const app = express();
const PORT = process.env.PORT || 3000;

// Middleware
app.use(cors());
app.use(bodyParser.json());
app.use(bodyParser.urlencoded({ extended: true }));

// Database connection
const db = mysql.createConnection({
    host: process.env.DB_HOST || 'localhost',
    user: process.env.DB_USER || 'root',
    password: process.env.DB_PASSWORD || '',
    database: process.env.DB_NAME || 'catering_reservations'
});

// Connect to database
db.connect((err) => {
    if (err) {
        console.error('Database connection error:', err);
        return;
    }
    console.log('Connected to MySQL database');
});

// Create reservations table if it doesn't exist
const createReservationsTable = `
    CREATE TABLE IF NOT EXISTS reservations (
        id INT AUTO_INCREMENT PRIMARY KEY,
        customer_name VARCHAR(255) NOT NULL,
        customer_email VARCHAR(255) NOT NULL,
        customer_phone VARCHAR(20) NOT NULL,
        event_date DATE NOT NULL,
        event_time TIME NOT NULL,
        guest_count INT NOT NULL,
        event_type VARCHAR(100),
        event_location TEXT NOT NULL,
        special_requests TEXT,
        total_amount DECIMAL(10, 2) DEFAULT 0.00,
        cart_items JSON,
        status ENUM('pending', 'confirmed', 'cancelled') DEFAULT 'pending',
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
    )
`;

db.query(createReservationsTable, (err) => {
    if (err) {
        console.error('Error creating reservations table:', err);
    } else {
        console.log('Reservations table ready');
    }
});

// Create contact_messages table if it doesn't exist
const createContactTable = `
    CREATE TABLE IF NOT EXISTS contact_messages (
        id INT AUTO_INCREMENT PRIMARY KEY,
        name VARCHAR(255) NOT NULL,
        email VARCHAR(255) NOT NULL,
        subject VARCHAR(255) NOT NULL,
        message TEXT NOT NULL,
        status ENUM('unread', 'read', 'replied') DEFAULT 'unread',
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
    )
`;

db.query(createContactTable, (err) => {
    if (err) {
        console.error('Error creating contact_messages table:', err);
    } else {
        console.log('Contact messages table ready');
    }
});

// Email transporter setup
const transporter = nodemailer.createTransport({
    service: 'gmail',
    auth: {
        user: process.env.EMAIL_USER,
        pass: process.env.EMAIL_PASS
    }
});

// Routes

// Health check
app.get('/api/health', (req, res) => {
    res.json({ status: 'Server is running', timestamp: new Date().toISOString() });
});

// Submit reservation
app.post('/api/reservations', async (req, res) => {
    try {
        const {
            customerName,
            customerEmail,
            customerPhone,
            eventDate,
            eventTime,
            guestCount,
            eventType,
            eventLocation,
            specialRequests,
            totalAmount,
            cartItems
        } = req.body;

        // Validate required fields
        if (!customerName || !customerEmail || !customerPhone || !eventDate || !eventTime || !guestCount || !eventLocation) {
            return res.status(400).json({
                success: false,
                message: 'Please fill in all required fields'
            });
        }

        // Validate email format
        const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
        if (!emailRegex.test(customerEmail)) {
            return res.status(400).json({
                success: false,
                message: 'Please enter a valid email address'
            });
        }

        // Validate date is not in the past
        const selectedDate = new Date(eventDate);
        const today = new Date();
        today.setHours(0, 0, 0, 0);
        
        if (selectedDate < today) {
            return res.status(400).json({
                success: false,
                message: 'Event date cannot be in the past'
            });
        }

        // Insert reservation into database
        const insertQuery = `
            INSERT INTO reservations (
                customer_name, customer_email, customer_phone, event_date, event_time,
                guest_count, event_type, event_location, special_requests, total_amount, cart_items
            ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
        `;

        const cartItemsJson = JSON.stringify(cartItems || []);
        const values = [
            customerName,
            customerEmail,
            customerPhone,
            eventDate,
            eventTime,
            guestCount,
            eventType || null,
            eventLocation,
            specialRequests || null,
            totalAmount || 0,
            cartItemsJson
        ];

        db.query(insertQuery, values, async (err, result) => {
            if (err) {
                console.error('Database error:', err);
                return res.status(500).json({
                    success: false,
                    message: 'Database error occurred'
                });
            }

            const reservationId = result.insertId;

            // Send confirmation email to customer
            try {
                await sendConfirmationEmail(customerEmail, customerName, reservationId, {
                    eventDate,
                    eventTime,
                    guestCount,
                    eventLocation,
                    eventType,
                    specialRequests,
                    totalAmount
                });
            } catch (emailError) {
                console.error('Email sending error:', emailError);
                // Don't fail the reservation if email fails
            }

            // Send notification email to business
            try {
                await sendBusinessNotification(reservationId, {
                    customerName,
                    customerEmail,
                    customerPhone,
                    eventDate,
                    eventTime,
                    guestCount,
                    eventLocation,
                    eventType,
                    specialRequests,
                    totalAmount,
                    cartItems
                });
            } catch (emailError) {
                console.error('Business notification error:', emailError);
            }

            res.json({
                success: true,
                message: 'Reservation submitted successfully!',
                reservationId: reservationId,
                data: {
                    id: reservationId,
                    customerName,
                    customerEmail,
                    eventDate,
                    eventTime,
                    guestCount,
                    status: 'pending'
                }
            });
        });

    } catch (error) {
        console.error('Server error:', error);
        res.status(500).json({
            success: false,
            message: 'Server error occurred'
        });
    }
});

// Get reservation by ID
app.get('/api/reservations/:id', (req, res) => {
    const reservationId = req.params.id;
    
    const query = 'SELECT * FROM reservations WHERE id = ?';
    
    db.query(query, [reservationId], (err, results) => {
        if (err) {
            console.error('Database error:', err);
            return res.status(500).json({
                success: false,
                message: 'Database error occurred'
            });
        }
        
        if (results.length === 0) {
            return res.status(404).json({
                success: false,
                message: 'Reservation not found'
            });
        }
        
        res.json({
            success: true,
            data: results[0]
        });
    });
});

// Get all reservations (for admin)
app.get('/api/reservations', (req, res) => {
    const { status, date, limit = 50, offset = 0 } = req.query;
    
    let query = 'SELECT * FROM reservations WHERE 1=1';
    const params = [];
    
    if (status) {
        query += ' AND status = ?';
        params.push(status);
    }
    
    if (date) {
        query += ' AND event_date = ?';
        params.push(date);
    }
    
    query += ' ORDER BY created_at DESC LIMIT ? OFFSET ?';
    params.push(parseInt(limit), parseInt(offset));
    
    db.query(query, params, (err, results) => {
        if (err) {
            console.error('Database error:', err);
            return res.status(500).json({
                success: false,
                message: 'Database error occurred'
            });
        }
        
        res.json({
            success: true,
            data: results,
            count: results.length
        });
    });
});

// Update reservation status
app.put('/api/reservations/:id/status', (req, res) => {
    const reservationId = req.params.id;
    const { status } = req.body;
    
    if (!['pending', 'confirmed', 'cancelled'].includes(status)) {
        return res.status(400).json({
            success: false,
            message: 'Invalid status value'
        });
    }
    
    const query = 'UPDATE reservations SET status = ? WHERE id = ?';
    
    db.query(query, [status, reservationId], (err, result) => {
        if (err) {
            console.error('Database error:', err);
            return res.status(500).json({
                success: false,
                message: 'Database error occurred'
            });
        }
        
        if (result.affectedRows === 0) {
            return res.status(404).json({
                success: false,
                message: 'Reservation not found'
            });
        }
        
        res.json({
            success: true,
            message: 'Reservation status updated successfully'
        });
    });
});

// Submit contact message
app.post('/api/contact', (req, res) => {
    const { name, email, subject, message } = req.body;
    
    if (!name || !email || !subject || !message) {
        return res.status(400).json({
            success: false,
            message: 'Please fill in all fields'
        });
    }
    
    const query = 'INSERT INTO contact_messages (name, email, subject, message) VALUES (?, ?, ?, ?)';
    
    db.query(query, [name, email, subject, message], (err, result) => {
        if (err) {
            console.error('Database error:', err);
            return res.status(500).json({
                success: false,
                message: 'Database error occurred'
            });
        }
        
        res.json({
            success: true,
            message: 'Message sent successfully!',
            messageId: result.insertId
        });
    });
});

// Email functions
async function sendConfirmationEmail(email, name, reservationId, details) {
    const mailOptions = {
        from: process.env.EMAIL_USER,
        to: email,
        subject: 'Reservation Confirmation - Shakthi Catering',
        html: `
            <h2>Reservation Confirmed!</h2>
            <p>Dear ${name},</p>
            <p>Thank you for choosing Shakthi Catering. Your reservation has been received and is being processed.</p>
            
            <h3>Reservation Details:</h3>
            <ul>
                <li><strong>Reservation ID:</strong> ${reservationId}</li>
                <li><strong>Event Date:</strong> ${details.eventDate}</li>
                <li><strong>Event Time:</strong> ${details.eventTime}</li>
                <li><strong>Number of Guests:</strong> ${details.guestCount}</li>
                <li><strong>Event Location:</strong> ${details.eventLocation}</li>
                <li><strong>Event Type:</strong> ${details.eventType || 'Not specified'}</li>
                <li><strong>Total Amount:</strong> ₹${details.totalAmount || 0}</li>
            </ul>
            
            ${details.specialRequests ? `<p><strong>Special Requests:</strong> ${details.specialRequests}</p>` : ''}
            
            <p>We will contact you within 24 hours to confirm the details and finalize your reservation.</p>
            
            <p>If you have any questions, please contact us at:</p>
            <p>Email: shakthiisivakumar@gmail.com<br>Phone: +91 123-4567</p>
            
            <p>Thank you for choosing Shakthi Catering!</p>
        `
    };
    
    await transporter.sendMail(mailOptions);
}

async function sendBusinessNotification(reservationId, details) {
    const mailOptions = {
        from: process.env.EMAIL_USER,
        to: process.env.BUSINESS_EMAIL || 'shakthiisivakumar@gmail.com',
        subject: `New Reservation #${reservationId} - Shakthi Catering`,
        html: `
            <h2>New Reservation Received</h2>
            
            <h3>Reservation Details:</h3>
            <ul>
                <li><strong>Reservation ID:</strong> ${reservationId}</li>
                <li><strong>Customer Name:</strong> ${details.customerName}</li>
                <li><strong>Customer Email:</strong> ${details.customerEmail}</li>
                <li><strong>Customer Phone:</strong> ${details.customerPhone}</li>
                <li><strong>Event Date:</strong> ${details.eventDate}</li>
                <li><strong>Event Time:</strong> ${details.eventTime}</li>
                <li><strong>Number of Guests:</strong> ${details.guestCount}</li>
                <li><strong>Event Location:</strong> ${details.eventLocation}</li>
                <li><strong>Event Type:</strong> ${details.eventType || 'Not specified'}</li>
                <li><strong>Total Amount:</strong> ₹${details.totalAmount || 0}</li>
            </ul>
            
            ${details.specialRequests ? `<p><strong>Special Requests:</strong> ${details.specialRequests}</p>` : ''}
            
            ${details.cartItems && details.cartItems.length > 0 ? `
                <h3>Cart Items:</h3>
                <ul>
                    ${details.cartItems.map(item => `
                        <li>${item.name} - Quantity: ${item.quantity} - Price: ₹${item.price}</li>
                    `).join('')}
                </ul>
            ` : ''}
            
            <p>Please contact the customer to confirm the reservation details.</p>
        `
    };
    
    await transporter.sendMail(mailOptions);
}

// Error handling middleware
app.use((err, req, res, next) => {
    console.error(err.stack);
    res.status(500).json({
        success: false,
        message: 'Something went wrong!'
    });
});

// Handle 404
app.use((req, res) => {
    res.status(404).json({
        success: false,
        message: 'API endpoint not found'
    });
});

// Start server
app.listen(PORT, () => {
    console.log(`Server running on port ${PORT}`);
    console.log(`Health check: http://localhost:${PORT}/api/health`);
});

module.exports = app;
