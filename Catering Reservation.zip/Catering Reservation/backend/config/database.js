const mysql = require('mysql2/promise');
require('dotenv').config();

// Database configuration
const dbConfig = {
    host: process.env.DB_HOST || 'localhost',
    user: process.env.DB_USER || 'root',
    password: process.env.DB_PASSWORD || '',
    database: process.env.DB_NAME || 'catering_reservations',
    waitForConnections: true,
    connectionLimit: 10,
    queueLimit: 0,
    acquireTimeout: 60000,
    timeout: 60000
};

// Create connection pool
const pool = mysql.createPool(dbConfig);

// Test database connection
async function testConnection() {
    try {
        const connection = await pool.getConnection();
        console.log('Database connected successfully');
        connection.release();
        return true;
    } catch (error) {
        console.error('Database connection failed:', error.message);
        return false;
    }
}

// Initialize database tables
async function initializeDatabase() {
    try {
        const connection = await pool.getConnection();
        
        // Create reservations table
        await connection.execute(`
            CREATE TABLE IF NOT EXISTS reservations (
                id INT AUTO_INCREMENT PRIMARY KEY,
                customer_name VARCHAR(255) NOT NULL,
                customer_email VARCHAR(255) NOT NULL,
                customer_phone VARCHAR(20) NOT NULL,
                event_date DATE NOT NULL,
                event_time TIME NOT NULL,
                guest_count INT NOT NULL,
                event_type VARCHAR(100),
                event_location TEXT NOT NULL,
                special_requests TEXT,
                total_amount DECIMAL(10, 2) DEFAULT 0.00,
                cart_items JSON,
                status ENUM('pending', 'confirmed', 'cancelled') DEFAULT 'pending',
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
                
                INDEX idx_customer_email (customer_email),
                INDEX idx_event_date (event_date),
                INDEX idx_status (status),
                INDEX idx_created_at (created_at)
            )
        `);
        
        // Create contact messages table
        await connection.execute(`
            CREATE TABLE IF NOT EXISTS contact_messages (
                id INT AUTO_INCREMENT PRIMARY KEY,
                name VARCHAR(255) NOT NULL,
                email VARCHAR(255) NOT NULL,
                subject VARCHAR(255) NOT NULL,
                message TEXT NOT NULL,
                status ENUM('unread', 'read', 'replied') DEFAULT 'unread',
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                
                INDEX idx_email (email),
                INDEX idx_status (status),
                INDEX idx_created_at (created_at)
            )
        `);
        
        connection.release();
        console.log('Database tables initialized successfully');
        return true;
    } catch (error) {
        console.error('Database initialization failed:', error.message);
        return false;
    }
}

// Execute query with error handling
async function executeQuery(query, params = []) {
    try {
        const connection = await pool.getConnection();
        const [results] = await connection.execute(query, params);
        connection.release();
        return { success: true, data: results };
    } catch (error) {
        console.error('Query execution failed:', error.message);
        return { success: false, error: error.message };
    }
}

// Close database connection
async function closeDatabase() {
    try {
        await pool.end();
        console.log('Database connection closed');
    } catch (error) {
        console.error('Error closing database:', error.message);
    }
}

module.exports = {
    pool,
    testConnection,
    initializeDatabase,
    executeQuery,
    closeDatabase
};
