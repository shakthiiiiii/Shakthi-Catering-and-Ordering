-- Database setup script for Shakthi Catering Reservation System

-- Create database if it doesn't exist
IF NOT EXISTS (SELECT name FROM sys.databases WHERE name = N'catering_reservations')
BEGIN
    EXEC('CREATE DATABASE catering_reservations');
END
GO
USE catering_reservations;

-- Create reservations table
CREATE TABLE IF NOT EXISTS reservations (
    id INT IDENTITY(1,1) PRIMARY KEY,
    customer_name VARCHAR(255) NOT NULL,
    customer_email VARCHAR(255) NOT NULL,
    customer_phone VARCHAR(20) NOT NULL,
    event_date DATE NOT NULL,
    event_time TIME NOT NULL,
    guest_count INT NOT NULL,
    event_type VARCHAR(100),
    event_location TEXT NOT NULL,
    special_requests TEXT,
    total_amount DECIMAL(10, 2) DEFAULT 0.00,
    cart_items JSON,
    status ENUM('pending', 'confirmed', 'cancelled') DEFAULT 'pending',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    
    INDEX idx_customer_email (customer_email),
    INDEX idx_event_date (event_date),
    INDEX idx_status (status),
    INDEX idx_created_at (created_at)
);

-- Create contact_messages table
CREATE TABLE IF NOT EXISTS contact_messages (
    id INT AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(255) NOT NULL,
    email VARCHAR(255) NOT NULL,
    subject VARCHAR(255) NOT NULL,
    message TEXT NOT NULL,
    status ENUM('unread', 'read', 'replied') DEFAULT 'unread',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    
    INDEX idx_email (email),
    INDEX idx_status (status),
    INDEX idx_created_at (created_at)
);

-- Create users table (for future authentication)
CREATE TABLE IF NOT EXISTS users (
    id INT AUTO_INCREMENT PRIMARY KEY,
    full_name VARCHAR(255) NOT NULL,
    email VARCHAR(255) UNIQUE NOT NULL,
    phone VARCHAR(20),
    password_hash VARCHAR(255) NOT NULL,
    role ENUM('customer', 'admin') DEFAULT 'customer',
    is_active BOOLEAN DEFAULT TRUE,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    
    INDEX idx_email (email),
    INDEX idx_role (role)
);

-- Create menu_items table (for future menu management)
CREATE TABLE IF NOT EXISTS menu_items (
    id INT AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(255) NOT NULL,
    category ENUM('appetizers', 'mains', 'desserts', 'beverages') NOT NULL,
    price DECIMAL(10, 2) NOT NULL,
    description TEXT,
    image_url VARCHAR(500),
    is_available BOOLEAN DEFAULT TRUE,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    
    INDEX idx_category (category),
    INDEX idx_is_available (is_available)
);

-- Insert sample menu items
INSERT INTO menu_items (name, category, price, description, image_url) VALUES
('Bruschetta Platter', 'appetizers', 59.00, 'Fresh tomatoes, basil, and mozzarella on toasted bread', 'https://images.unsplash.com/photo-1572695157366-5e585ab2b69f?w=400&h=300&fit=crop'),
('Garlic Bread', 'appetizers', 79.00, 'Crispy golden bread with aromatic garlic and herbs', 'https://images.unsplash.com/photo-1573821663912-6df460f9c684?w=400&h=300&fit=crop'),
('Stuffed Mushrooms', 'appetizers', 99.00, 'Button mushrooms stuffed with herbs, cheese, and breadcrumbs', 'https://images.unsplash.com/photo-1504674900247-0877df9cc836?w=400&h=300&fit=crop'),
('Pizza(Customizable)', 'mains', 249.00, 'Wood-fired pizza with your choice of toppings', 'https://images.unsplash.com/photo-1513104890138-7c749659a591?w=400&h=300&fit=crop'),
('Italian Pasta(Customizable)', 'mains', 299.00, 'Authentic Italian pasta with choice of sauce and ingredients', 'https://images.unsplash.com/photo-1551183053-bf91a1d81141?w=400&h=300&fit=crop'),
('Burger(Customizable)', 'mains', 109.00, 'Juicy burger with fresh ingredients and choice of toppings', 'https://images.unsplash.com/photo-1568901346375-23c9450c58cd?w=400&h=300&fit=crop'),
('Chocolate Mousse Cake', 'desserts', 99.00, 'Rich chocolate mousse with berry compote', 'https://images.unsplash.com/photo-1578985545062-69928b1d9587?w=400&h=300&fit=crop'),
('Tiramisu', 'desserts', 99.00, 'Classic Italian dessert with coffee and mascarpone', 'https://images.unsplash.com/photo-1571877227200-a0d98ea607e9?w=400&h=300&fit=crop'),
('Fruit Tart', 'desserts', 79.00, 'Pastry shell with vanilla custard and fresh seasonal fruits', 'https://images.unsplash.com/photo-1464349095431-e9a21285b5f3?w=400&h=300&fit=crop'),
('Hot Drinks', 'beverages', 25.00, 'Freshly brewed coffee, tea, and hot chocolate varieties', 'https://images.unsplash.com/photo-1495474472287-4d71bcdd2085?w=400&h=300&fit=crop'),
('Cold Drinks', 'beverages', 60.00, 'Refreshing sodas, iced teas, and soft drinks', 'https://images.unsplash.com/photo-1544145945-f90425340c7e?w=400&h=300&fit=crop'),
('Fresh Juices', 'beverages', 70.00, 'Freshly squeezed fruit juices and smoothies', 'https://images.unsplash.com/photo-1513558161293-cdaf765ed2fd?w=400&h=300&fit=crop');

-- Create admin user (password: admin123)
INSERT INTO users (full_name, email, password_hash, role) VALUES
('Admin User', 'admin@shakthicatering.com', '$2b$10$rQhyJEDQCjMxJVdwYL0XGOhzjJl2Zv.3kNxhsZgdVGxQQOiL6zCwq', 'admin');

COMMIT;
