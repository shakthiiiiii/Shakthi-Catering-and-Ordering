const express = require('express');
const cors = require('cors');
const nodemailer = require('nodemailer');
require('dotenv').config();

const app = express();
const PORT = process.env.PORT || 3000;

// Middleware
app.use(cors());
app.use(express.json());

// In-memory storage for testing (replace with database in production)
const reservations = [];
const contacts = [];

// Email transporter setup
const transporter = nodemailer.createTransport({
    service: 'gmail',
    auth: {
        user: process.env.EMAIL_USER,
        pass: process.env.EMAIL_PASS
    }
});

// Health check endpoint
app.get('/api/health', (req, res) => {
    res.json({
        status: 'Server is running',
        timestamp: new Date().toISOString()
    });
});

// Get all reservations
app.get('/api/reservations', (req, res) => {
    res.json({
        success: true,
        data: reservations
    });
});

// Submit reservation
app.post('/api/reservations', async (req, res) => {
    try {
        const {
            customerName,
            customerEmail,
            customerPhone,
            eventDate,
            eventTime,
            guestCount,
            eventType,
            eventLocation,
            specialRequests,
            totalAmount = 0,
            cartItems = []
        } = req.body;

        // Validate required fields
        if (!customerName || !customerEmail || !customerPhone || !eventDate || !eventTime || !guestCount || !eventLocation) {
            return res.status(400).json({
                success: false,
                message: 'Missing required fields'
            });
        }

        // Create reservation object
        const reservation = {
            id: Date.now(), // Simple ID generation
            customerName,
            customerEmail,
            customerPhone,
            eventDate,
            eventTime,
            guestCount: parseInt(guestCount),
            eventType: eventType || 'other',
            eventLocation,
            specialRequests: specialRequests || '',
            totalAmount: parseFloat(totalAmount),
            cartItems: JSON.stringify(cartItems),
            status: 'pending',
            createdAt: new Date().toISOString(),
            updatedAt: new Date().toISOString()
        };

        // Store in memory
        reservations.push(reservation);

        // Send confirmation email (if email is configured)
        if (process.env.EMAIL_USER && process.env.EMAIL_PASS) {
            try {
                const mailOptions = {
                    from: process.env.EMAIL_USER,
                    to: customerEmail,
                    subject: 'Reservation Confirmation - Shakthi Catering',
                    html: `
                        <div style="font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto;">
                            <h2 style="color: #2c3e50;">Reservation Confirmation</h2>
                            <p>Dear ${customerName},</p>
                            <p>Thank you for choosing Shakthi Catering! Your reservation has been successfully submitted.</p>
                            
                            <div style="background-color: #f8f9fa; padding: 20px; border-radius: 5px; margin: 20px 0;">
                                <h3 style="color: #495057;">Reservation Details:</h3>
                                <p><strong>Event Date:</strong> ${eventDate}</p>
                                <p><strong>Event Time:</strong> ${eventTime}</p>
                                <p><strong>Number of Guests:</strong> ${guestCount}</p>
                                <p><strong>Event Type:</strong> ${eventType}</p>
                                <p><strong>Location:</strong> ${eventLocation}</p>
                                <p><strong>Total Amount:</strong> ₹${totalAmount}</p>
                                ${specialRequests ? `<p><strong>Special Requests:</strong> ${specialRequests}</p>` : ''}
                            </div>
                            
                            <p>We will contact you within 24 hours to confirm your reservation and discuss menu options.</p>
                            
                            <p>Best regards,<br>
                            Shakthi Catering Team<br>
                            Phone: +91 123-4567<br>
                            Email: shakthiisivakumar@gmail.com</p>
                        </div>
                    `
                };

                await transporter.sendMail(mailOptions);
                console.log('✅ Confirmation email sent to:', customerEmail);
            } catch (emailError) {
                console.log('⚠️ Email sending failed:', emailError.message);
            }
        }

        res.json({
            success: true,
            message: 'Reservation submitted successfully!',
            data: reservation
        });

    } catch (error) {
        console.error('Error submitting reservation:', error);
        res.status(500).json({
            success: false,
            message: 'Error submitting reservation. Please try again.'
        });
    }
});

// Get reservation by ID
app.get('/api/reservations/:id', (req, res) => {
    const reservation = reservations.find(r => r.id === parseInt(req.params.id));
    
    if (!reservation) {
        return res.status(404).json({
            success: false,
            message: 'Reservation not found'
        });
    }

    res.json({
        success: true,
        data: reservation
    });
});

// Update reservation status
app.put('/api/reservations/:id/status', (req, res) => {
    const { status } = req.body;
    const reservation = reservations.find(r => r.id === parseInt(req.params.id));
    
    if (!reservation) {
        return res.status(404).json({
            success: false,
            message: 'Reservation not found'
        });
    }

    reservation.status = status;
    reservation.updatedAt = new Date().toISOString();

    res.json({
        success: true,
        message: 'Reservation status updated successfully',
        data: reservation
    });
});

// Submit contact message
app.post('/api/contact', async (req, res) => {
    try {
        const { name, email, subject, message } = req.body;

        // Validate required fields
        if (!name || !email || !subject || !message) {
            return res.status(400).json({
                success: false,
                message: 'All fields are required'
            });
        }

        // Create contact message object
        const contactMessage = {
            id: Date.now(),
            name,
            email,
            subject,
            message,
            status: 'unread',
            createdAt: new Date().toISOString()
        };

        // Store in memory
        contacts.push(contactMessage);

        // Send notification email to business
        if (process.env.EMAIL_USER && process.env.EMAIL_PASS) {
            try {
                const mailOptions = {
                    from: process.env.EMAIL_USER,
                    to: process.env.BUSINESS_EMAIL,
                    subject: `New Contact Message: ${subject}`,
                    html: `
                        <div style="font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto;">
                            <h2 style="color: #2c3e50;">New Contact Message</h2>
                            <p><strong>From:</strong> ${name}</p>
                            <p><strong>Email:</strong> ${email}</p>
                            <p><strong>Subject:</strong> ${subject}</p>
                            <div style="background-color: #f8f9fa; padding: 20px; border-radius: 5px; margin: 20px 0;">
                                <h3>Message:</h3>
                                <p>${message}</p>
                            </div>
                        </div>
                    `
                };

                await transporter.sendMail(mailOptions);
                console.log('✅ Contact message notification sent');
            } catch (emailError) {
                console.log('⚠️ Email sending failed:', emailError.message);
            }
        }

        res.json({
            success: true,
            message: 'Message sent successfully!'
        });

    } catch (error) {
        console.error('Error submitting contact message:', error);
        res.status(500).json({
            success: false,
            message: 'Error submitting message. Please try again.'
        });
    }
});

// Start server
app.listen(PORT, () => {
    console.log(`Server running on port ${PORT}`);
    console.log(`Health check: http://localhost:${PORT}/api/health`);
    console.log('📝 Using in-memory storage for testing');
    console.log('🚀 Server is ready to accept reservations!');
});
