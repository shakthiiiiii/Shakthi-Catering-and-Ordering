# Catering Reservation Backend

A robust Node.js backend API for the Shakthi Catering Reservation System with MySQL database integration.

## Features

- **Reservation Management**: Store and manage customer reservations
- **Contact Messages**: Handle customer inquiries
- **Email Notifications**: Automatic confirmation emails
- **Data Validation**: Comprehensive input validation
- **Database Integration**: MySQL with connection pooling
- **Error Handling**: Robust error handling and logging
- **CORS Support**: Cross-origin resource sharing enabled

## Prerequisites

- Node.js (v14 or higher)
- MySQL Server (v8.0 or higher)
- Gmail account (for email notifications)

## Installation

1. **Navigate to the backend directory**:
   ```bash
   cd "c:\Shakthi\Catering Reservation\backend"
   ```

2. **Install dependencies**:
   ```bash
   npm install
   ```

3. **Set up environment variables**:
   - Copy `.env.example` to `.env`
   - Update the values in `.env` with your configuration

4. **Set up MySQL database**:
   - Create a new MySQL database named `catering_reservations`
   - Run the SQL script: `mysql -u root -p catering_reservations < database_setup.sql`

5. **Start the server**:
   ```bash
   npm start
   ```
   
   For development with auto-reload:
   ```bash
   npm run dev
   ```

## Environment Configuration

Create a `.env` file in the backend directory with the following variables:

```env
# Server Configuration
PORT=3000

# Database Configuration
DB_HOST=localhost
DB_USER=root
DB_PASSWORD=your_mysql_password
DB_NAME=catering_reservations

# Email Configuration (Gmail)
EMAIL_USER=your_email@gmail.com
EMAIL_PASS=your_app_password
BUSINESS_EMAIL=shakthiisivakumar@gmail.com

# JWT Secret (for future authentication)
JWT_SECRET=your_jwt_secret_key_here

# Environment
NODE_ENV=development
```

## API Endpoints

### Health Check
- **GET** `/api/health` - Server health check

### Reservations
- **POST** `/api/reservations` - Submit new reservation
- **GET** `/api/reservations/:id` - Get reservation by ID
- **GET** `/api/reservations` - Get all reservations (with filters)
- **PUT** `/api/reservations/:id/status` - Update reservation status

### Contact Messages
- **POST** `/api/contact` - Submit contact message

## API Usage Examples

### Submit Reservation
```javascript
const reservationData = {
    customerName: "John Doe",
    customerEmail: "john@example.com",
    customerPhone: "+91 9876543210",
    eventDate: "2025-08-15",
    eventTime: "18:00",
    guestCount: 50,
    eventType: "wedding",
    eventLocation: "Grand Hall, Mumbai",
    specialRequests: "Vegetarian menu preferred",
    totalAmount: 15000,
    cartItems: [
        { id: 1, name: "Appetizer Platter", quantity: 2, price: 500 }
    ]
};

fetch('http://localhost:3000/api/reservations', {
    method: 'POST',
    headers: {
        'Content-Type': 'application/json',
    },
    body: JSON.stringify(reservationData)
})
.then(response => response.json())
.then(data => console.log(data));
```

### Get Reservation
```javascript
fetch('http://localhost:3000/api/reservations/123')
    .then(response => response.json())
    .then(data => console.log(data));
```

## Database Schema

### Reservations Table
- `id` (INT, AUTO_INCREMENT, PRIMARY KEY)
- `customer_name` (VARCHAR(255), NOT NULL)
- `customer_email` (VARCHAR(255), NOT NULL)
- `customer_phone` (VARCHAR(20), NOT NULL)
- `event_date` (DATE, NOT NULL)
- `event_time` (TIME, NOT NULL)
- `guest_count` (INT, NOT NULL)
- `event_type` (VARCHAR(100))
- `event_location` (TEXT, NOT NULL)
- `special_requests` (TEXT)
- `total_amount` (DECIMAL(10,2), DEFAULT 0.00)
- `cart_items` (JSON)
- `status` (ENUM: 'pending', 'confirmed', 'cancelled')
- `created_at` (TIMESTAMP)
- `updated_at` (TIMESTAMP)

### Contact Messages Table
- `id` (INT, AUTO_INCREMENT, PRIMARY KEY)
- `name` (VARCHAR(255), NOT NULL)
- `email` (VARCHAR(255), NOT NULL)
- `subject` (VARCHAR(255), NOT NULL)
- `message` (TEXT, NOT NULL)
- `status` (ENUM: 'unread', 'read', 'replied')
- `created_at` (TIMESTAMP)

## Email Configuration

For Gmail integration:
1. Enable 2-factor authentication on your Gmail account
2. Generate an App Password:
   - Go to Google Account settings
   - Security > App passwords
   - Generate password for "Mail"
3. Use this app password in the `EMAIL_PASS` environment variable

## Error Handling

The API returns consistent error responses:

```json
{
    "success": false,
    "message": "Error description"
}
```

## Success Responses

All successful API calls return:

```json
{
    "success": true,
    "message": "Success message",
    "data": {...}
}
```

## Logging

The server logs important events to the console:
- Database connections
- API requests
- Email sending
- Errors and warnings

## Security Features

- Input validation and sanitization
- SQL injection prevention
- CORS configuration
- Environment variable protection
- Error message sanitization

## Future Enhancements

- JWT authentication system
- Rate limiting
- API documentation with Swagger
- Database migrations
- Unit and integration tests
- Admin dashboard
- Real-time notifications

## Troubleshooting

### Common Issues

1. **Database Connection Error**:
   - Check MySQL server is running
   - Verify database credentials in `.env`
   - Ensure database exists

2. **Email Not Sending**:
   - Check Gmail app password
   - Verify email configuration
   - Check firewall/antivirus settings

3. **Port Already in Use**:
   - Change PORT in `.env` file
   - Kill existing processes on port 3000

4. **CORS Issues**:
   - Ensure frontend is running on allowed origin
   - Check CORS configuration in server.js

## Testing

Test the API endpoints using tools like:
- Postman
- curl
- Thunder Client (VS Code extension)
- Browser Developer Tools

## Support

For support and questions:
- Email: shakthiisivakumar@gmail.com
- Check server logs for detailed error information
- Verify environment configuration

---

Made with ❤️ for Shakthi Catering Reservation System
