const functions = require('firebase-functions');
const admin = require('firebase-admin');
const express = require('express');
const cors = require('cors');
const nodemailer = require('nodemailer');

// Initialize Firebase Admin
admin.initializeApp();

const app = express();
app.use(cors({ origin: true }));
app.use(express.json());

// Get Firestore instance
const db = admin.firestore();

// Email transporter setup
const transporter = nodemailer.createTransport({
    service: 'gmail',
    auth: {
        user: functions.config().email.user,
        pass: functions.config().email.pass
    }
});

// Health check endpoint
app.get('/health', (req, res) => {
    res.json({
        status: 'Server is running',
        timestamp: new Date().toISOString()
    });
});

// Submit reservation
app.post('/reservations', async (req, res) => {
    try {
        const {
            customerName,
            customerEmail,
            customerPhone,
            eventDate,
            eventTime,
            guestCount,
            eventType,
            eventLocation,
            specialRequests,
            totalAmount = 0,
            cartItems = []
        } = req.body;

        // Validate required fields
        if (!customerName || !customerEmail || !customerPhone || !eventDate || !eventTime || !guestCount || !eventLocation) {
            return res.status(400).json({
                success: false,
                message: 'Missing required fields'
            });
        }

        // Create reservation object
        const reservation = {
            customerName,
            customerEmail,
            customerPhone,
            eventDate,
            eventTime,
            guestCount: parseInt(guestCount),
            eventType: eventType || 'other',
            eventLocation,
            specialRequests: specialRequests || '',
            totalAmount: parseFloat(totalAmount),
            cartItems: cartItems,
            status: 'pending',
            createdAt: admin.firestore.FieldValue.serverTimestamp(),
            updatedAt: admin.firestore.FieldValue.serverTimestamp()
        };

        // Save to Firestore
        const docRef = await db.collection('reservations').add(reservation);

        // Send confirmation email
        try {
            const businessEmail = functions.config().email.business || 'shakthiisivakumar@gmail.com';
            
            const mailOptions = {
                from: functions.config().email.user,
                to: customerEmail,
                subject: 'Reservation Confirmation - Shakthi Catering',
                html: `
                    <div style="font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto;">
                        <h2 style="color: #2c3e50;">Reservation Confirmation</h2>
                        <p>Dear ${customerName},</p>
                        <p>Thank you for choosing Shakthi Catering! Your reservation has been successfully submitted.</p>
                        
                        <div style="background-color: #f8f9fa; padding: 20px; border-radius: 5px; margin: 20px 0;">
                            <h3 style="color: #495057;">Reservation Details:</h3>
                            <p><strong>Reservation ID:</strong> ${docRef.id}</p>
                            <p><strong>Event Date:</strong> ${eventDate}</p>
                            <p><strong>Event Time:</strong> ${eventTime}</p>
                            <p><strong>Number of Guests:</strong> ${guestCount}</p>
                            <p><strong>Event Type:</strong> ${eventType}</p>
                            <p><strong>Location:</strong> ${eventLocation}</p>
                            <p><strong>Total Amount:</strong> ₹${totalAmount}</p>
                            ${specialRequests ? `<p><strong>Special Requests:</strong> ${specialRequests}</p>` : ''}
                        </div>
                        
                        <p>We will contact you within 24 hours to confirm your reservation and discuss menu options.</p>
                        
                        <p>Best regards,<br>
                        Shakthi Catering Team<br>
                        Phone: +91 123-4567<br>
                        Email: ${businessEmail}</p>
                    </div>
                `
            };

            await transporter.sendMail(mailOptions);
            console.log('✅ Confirmation email sent to:', customerEmail);
        } catch (emailError) {
            console.log('⚠️ Email sending failed:', emailError.message);
        }

        res.json({
            success: true,
            message: 'Reservation submitted successfully!',
            data: { id: docRef.id, ...reservation }
        });

    } catch (error) {
        console.error('Error submitting reservation:', error);
        res.status(500).json({
            success: false,
            message: 'Error submitting reservation. Please try again.'
        });
    }
});

// Get all reservations
app.get('/reservations', async (req, res) => {
    try {
        const snapshot = await db.collection('reservations').orderBy('createdAt', 'desc').get();
        const reservations = [];
        
        snapshot.forEach(doc => {
            reservations.push({ id: doc.id, ...doc.data() });
        });

        res.json({
            success: true,
            data: reservations
        });
    } catch (error) {
        console.error('Error fetching reservations:', error);
        res.status(500).json({
            success: false,
            message: 'Error fetching reservations'
        });
    }
});

// Get reservation by ID
app.get('/reservations/:id', async (req, res) => {
    try {
        const doc = await db.collection('reservations').doc(req.params.id).get();
        
        if (!doc.exists) {
            return res.status(404).json({
                success: false,
                message: 'Reservation not found'
            });
        }

        res.json({
            success: true,
            data: { id: doc.id, ...doc.data() }
        });
    } catch (error) {
        console.error('Error fetching reservation:', error);
        res.status(500).json({
            success: false,
            message: 'Error fetching reservation'
        });
    }
});

// Update reservation status
app.put('/reservations/:id/status', async (req, res) => {
    try {
        const { status } = req.body;
        
        await db.collection('reservations').doc(req.params.id).update({
            status: status,
            updatedAt: admin.firestore.FieldValue.serverTimestamp()
        });

        res.json({
            success: true,
            message: 'Reservation status updated successfully'
        });
    } catch (error) {
        console.error('Error updating reservation status:', error);
        res.status(500).json({
            success: false,
            message: 'Error updating reservation status'
        });
    }
});

// Submit contact message
app.post('/contact', async (req, res) => {
    try {
        const { name, email, subject, message } = req.body;

        // Validate required fields
        if (!name || !email || !subject || !message) {
            return res.status(400).json({
                success: false,
                message: 'All fields are required'
            });
        }

        // Create contact message object
        const contactMessage = {
            name,
            email,
            subject,
            message,
            status: 'unread',
            createdAt: admin.firestore.FieldValue.serverTimestamp()
        };

        // Save to Firestore
        const docRef = await db.collection('contact_messages').add(contactMessage);

        // Send notification email to business
        try {
            const businessEmail = functions.config().email.business || 'shakthiisivakumar@gmail.com';
            
            const mailOptions = {
                from: functions.config().email.user,
                to: businessEmail,
                subject: `New Contact Message: ${subject}`,
                html: `
                    <div style="font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto;">
                        <h2 style="color: #2c3e50;">New Contact Message</h2>
                        <p><strong>From:</strong> ${name}</p>
                        <p><strong>Email:</strong> ${email}</p>
                        <p><strong>Subject:</strong> ${subject}</p>
                        <div style="background-color: #f8f9fa; padding: 20px; border-radius: 5px; margin: 20px 0;">
                            <h3>Message:</h3>
                            <p>${message}</p>
                        </div>
                        <p><strong>Message ID:</strong> ${docRef.id}</p>
                    </div>
                `
            };

            await transporter.sendMail(mailOptions);
            console.log('✅ Contact message notification sent');
        } catch (emailError) {
            console.log('⚠️ Email sending failed:', emailError.message);
        }

        res.json({
            success: true,
            message: 'Message sent successfully!'
        });

    } catch (error) {
        console.error('Error submitting contact message:', error);
        res.status(500).json({
            success: false,
            message: 'Error submitting message. Please try again.'
        });
    }
});

// Export the API
exports.api = functions.https.onRequest(app);
